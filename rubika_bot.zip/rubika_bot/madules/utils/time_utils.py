#time_utils.py
from datetime import datetime
import pytz


def get_tehran_time() -> datetime:
    # Define Tehran timezone
    tehran_tz = pytz.timezone('Asia/Tehran')
    # Return current datetime in Tehran timezone
    return datetime.now(tehran_tz)
