import os
import uuid
from PIL import Image

TEMP_DIR = './files/temp_images'
os.makedirs(TEMP_DIR, exist_ok=True)

def convert_to_jpg(src_path: str, max_size: int = 300 * 1024) -> str | None:
    try:
        with Image.open(src_path) as img:
            img = img.convert('RGB')

            img.thumbnail((640, 640))

            temp_path = os.path.join(TEMP_DIR, f"{uuid.uuid4()}.jpg")

            quality = 60
            while quality >= 10:
                img.save(temp_path, 'JPEG', quality=quality)
                if os.path.getsize(temp_path) <= max_size:
                    return temp_path
                quality -= 5

            if os.path.exists(temp_path):
                os.remove(temp_path)
            return None

    except Exception as e:
        print(f"Error during image conversion: {e}")
        return None
