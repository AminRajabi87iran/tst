#file_utils.py
def save_file_inline(bot_client, file_inline, save_path):
    # Download the inline file and save it to the specified path
    try:
        data = bot_client.download(file_inline)
        with open(save_path, 'wb') as f:
            f.write(data)
    except Exception as e:
        print(f"Error in downloading: {e}")
