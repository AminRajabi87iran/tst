import os

async def send_banner_list(bot, chat_id, banner, index=None):
    caption = ""
    if index is not None:
        caption += f"{index + 1}. "
    caption += banner.get("text", "")

    times_text = ""
    if banner.get('times'):
        times_text = f"ساعت‌ها: {', '.join(banner['times'])}"
    banner_id = banner.get('id', 'بدون شناسه')
    times_text += f"\nشناسه: {banner_id}"

    if banner.get('image') and os.path.exists(banner['image']):
        try:
            await bot.send_photo(chat_id, photo=banner['image'], caption=caption)
        except:
            await bot.send_message(chat_id, caption)
    else:
        await bot.send_message(chat_id, caption)

    if times_text.strip():
        await bot.send_message(chat_id, times_text)


async def send_banner(bot, chat_id, banner, index=None):
    caption = ""
    if index is not None:
        caption += f"{index + 1}. "
    caption += banner.get("text", "")

    if banner.get('image') and os.path.exists(banner['image']):
        try:
            await bot.send_photo(chat_id, photo=banner['image'], caption=caption)
        except:
            await bot.send_message(chat_id, caption)
    else:
        await bot.send_message(chat_id, caption)


async def send_result(bot, chat_id, banner, time, index=None):
    try:
        caption = ""
        if index is not None:
            caption += f"{index + 1}. "
        caption += f"{banner.get('id', 'بدون شناسه')}"
        final = f'بنر با شناسه "{caption}" در ساعت "{time}" ارسال شد'
    except:
        pass
    else:
        await bot.send_message(chat_id, final)
