# group_utils.py
async def get_group_ids(client):
    try:
        dialogs = await client.get_chats()
        groups = [
            chat['object_guid']
            for chat in dialogs['chats']
            if chat['abs_object']['type'] == 'Group'
        ]
        return groups
    except Exception as e:
        print(f"Error fetching groups: {e}")
        return []

async def send_message_to_all_groups(client, message_text, photo_path=None):
    group_ids = await get_group_ids(client)
    if not group_ids:
        print("No groups found.")
        return

    for group_id in group_ids:
        try:
            if photo_path:
                await client.send_photo(group_id, photo_path, caption=message_text)
            else:
                await client.send_message(group_id, message_text)
            print(f"Sent message to group {group_id}")
        except Exception as e:
            print(f"Failed to send to {group_id}: {e}")
