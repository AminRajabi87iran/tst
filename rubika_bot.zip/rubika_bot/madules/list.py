from madules.utils.send_utils import send_banner_list

async def handle_list_banners(chat_id, bot, banners):
    if banners:
        for i, banner in enumerate(banners):
            await send_banner_list(bot, chat_id, banner, index=i)
    else:
        await bot.send_message(chat_id, "هیچ بنری ثبت نشده است.")
