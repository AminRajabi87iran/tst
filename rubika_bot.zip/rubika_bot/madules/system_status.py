import psutil
import time


def monitor_system(bot, chat_id, interval=1):
    try:
        # CPU Usage
        cpu_percent = psutil.cpu_percent(interval=interval)
        cpu_count = psutil.cpu_count(logical=True)

        # RAM Usage
        ram = psutil.virtual_memory()
        ram_total = round(ram.total / (1024 ** 3), 2)  # in GB
        ram_used = round(ram.used / (1024 ** 3), 2)
        ram_percent = ram.percent


        sys_info = f"Cpu : {cpu_percent}% ({cpu_count} cores)\nRam : {ram_used} / {ram_total}GB ({ram_percent}%)"
        bot.send_message(chat_id, sys_info)
        time.sleep(5)


    except KeyboardInterrupt:
        print("Monitoring stopped.")
