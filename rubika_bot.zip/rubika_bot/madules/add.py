#add,py
import uuid
import os
from madules.utils.image_utils import convert_to_jpg
from madules.utils.file_utils import save_file_inline

IMAGES_DIR = './files/banner_images'
if not os.path.exists(IMAGES_DIR):
    os.makedirs(IMAGES_DIR)

def handle_add_banner(
    chat_id: str,
    text: str,
    message,
    bot,
    pending_banners
) :
    if chat_id not in pending_banners:
        # Start adding banner process
        pending_banners[chat_id] = {
            "text": "",
            "image": None,
            "waiting_for_text": True,
            "waiting_for_image": False,
            "waiting_for_times": False,
            "times": []
        }
        bot.send_message(chat_id, "لطفا متن بنر را وارد کنید:")
        return True

    data = pending_banners[chat_id]

    if data.get("waiting_for_text", False):
        if text:
            data["text"] = text
            data["waiting_for_text"] = False
            data["waiting_for_image"] = True
            bot.send_message(chat_id, "متن ذخیره شد. تصویر بنر را ارسال کنید یا بنویسید skip.")
        else:
            bot.send_message(chat_id, "لطفا متن صحیحی وارد کنید.")
        return True

    if data.get("waiting_for_image", False):
        if text.lower() == "skip":
            data["waiting_for_image"] = False
            data["waiting_for_times"] = True
            bot.send_message(chat_id, 'مرحله تصویر رد شد. لطفا لیست ساعت‌ها را ارسال کنید.مثال:\n["12:30","22:00"]')
            return True

        file_inline = getattr(getattr(message, 'message', None), 'file_inline', None)
        if file_inline:
            file_path = os.path.join(IMAGES_DIR, f"{uuid.uuid4()}.png")
            save_file_inline(bot, file_inline, file_path)
            try:
                jpg_path = convert_to_jpg(file_path)
            except Exception:
                jpg_path = file_path
            data["image"] = jpg_path
            data["waiting_for_image"] = False
            data["waiting_for_times"] = True
            bot.send_message(chat_id, 'تصویر بنر ذخیره شد. حالا لیست ساعت‌ها را ارسال کنید.مثال:\n["12:30","22:00"]')
        else:
            bot.send_message(chat_id, "تصویر نامعتبر است. دوباره تصویر را ارسال کنید یا بنویسید skip.")
        return True

    if data.get("waiting_for_times", False):
        if text:
            import json
            try:
                times = json.loads(text)
                if isinstance(times, list) and all(isinstance(t, str) for t in times):
                    data["times"] = times
                    data["waiting_for_times"] = False
                    data["id"] = str(uuid.uuid4())[:8]
                    # Save banner (called from main)
                    return "save"
                else:
                    bot.send_message(chat_id, 'فرمت ساعت‌ها نادرست است.مثال:\n["12:30","22:00"]')
            except:
                bot.send_message(chat_id, 'فرمت ساعت‌ها اشتباه است.مثال:\n["12:30","22:00"]')
        return True

    return False
