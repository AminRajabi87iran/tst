import asyncio
import os
from datetime import datetime
from pytz import timezone
from madules.utils.group_utils import get_group_ids
from madules.utils.send_utils import send_banner, send_result


def run_scheduler(bot, load_banners, saved_msg):
    async def send_due_banners():
        sent_flags = {}

        while True:
            now_time = datetime.now(timezone('Asia/Tehran')).strftime('%H:%M')
            banners = load_banners()

            if sent_flags.get(now_time):
                await asyncio.sleep(5)
                continue
            sent_flags[now_time] = True

            group_ids = await get_group_ids(bot)

            try:
                last_banner = None
                send_time = None
                for banner in banners:
                    if now_time in banner.get("times", []):
                        for group_id in group_ids:
                            try:
                                await send_banner(bot, group_id, banner)
                                last_banner = banner
                                send_time = now_time
                            except Exception as e:
                                print(f"Error sending banner to group {group_id}: {e}")
            except:
                pass
            else:
                await send_result(bot=bot, chat_id=saved_msg, time=send_time, banner=last_banner)

            await asyncio.sleep(60)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(send_due_banners())
