#storage.py
import json
import os

BANNERS_FILE = './files/banners.json'


def load_banners():
    # Load banners from JSON file
    if not os.path.exists(BANNERS_FILE):
        return []
    with open(BANNERS_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_banners(banners):
    # Save banners to JSON file
    with open(BANNERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(banners, f, ensure_ascii=False, indent=2)


def delete_banner_by_id(banner_id, banners, save_func):
    # Delete a banner by its ID and remove its image file if exists
    for idx, banner in enumerate(banners):
        if banner.get("id") == banner_id:
            image = banner.get("image")
            if image and os.path.exists(image):
                try:
                    os.remove(image)
                except Exception as e:
                    print(f"Error deleting image: {e}")
            del banners[idx]
            save_func(banners)
            return True
    return False
