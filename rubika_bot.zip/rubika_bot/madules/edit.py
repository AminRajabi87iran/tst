#edit.py
import json
import os
import uuid
from madules.utils.image_utils import convert_to_jpg
from madules.utils.file_utils import save_file_inline

IMAGES_DIR = './files/banner_images'

def handle_edit_banner(chat_id, text, message, bot, editing_banners, banners, save_banners):
    # Check if user is currently editing a banner
    if chat_id not in editing_banners:
        return False

    edit_data = editing_banners[chat_id]
    step = edit_data['step']
    banner = edit_data['banner']
    index = edit_data['index']

    # Step 0: Edit banner text or skip
    if step == 0:
        if text.lower() != "skip":
            banner['text'] = text
        bot.send_message(chat_id, "اگر می‌خواهید تصویر را تغییر دهید، آن را ارسال کنید یا بنویسید 'skip'.")
        edit_data['step'] = 1
        return True

    # Step 1: Edit banner image or skip
    if step == 1:
        if text.lower() == 'skip':
            edit_data['step'] = 2
            bot.send_message(chat_id, "لطفاً لیست جدید ساعت‌ها را به صورت [\"HH:MM\"] ارسال کنید یا بنویسید 'skip'.")
            return True

        # Try to get image file from the message
        file_inline = getattr(getattr(message, 'message', None), 'file_inline', None)
        if file_inline:
            file_path = os.path.join(IMAGES_DIR, f"{uuid.uuid4()}.png")
            save_file_inline(bot, file_inline, file_path)
            try:
                jpg_path = convert_to_jpg(file_path)
            except Exception:
                jpg_path = file_path

            # Remove old image file if exists
            old_image = banner.get('image')
            if old_image and os.path.exists(old_image):
                try:
                    os.remove(old_image)
                except Exception as e:
                    print(f"خطا در حذف تصویر قبلی: {e}")

            banner['image'] = jpg_path
            bot.send_message(chat_id, "تصویر تغییر کرد. لطفاً لیست جدید ساعت‌ها را ارسال کنید یا بنویسید 'skip'.")
            edit_data['step'] = 2
        else:
            bot.send_message(chat_id, "تصویر ارسال نشده یا نامعتبر است. یا تصویر را ارسال کنید یا بنویسید 'skip'.")
        return True

    # Step 2: Edit banner times or skip
    if step == 2:
        if text.lower() != 'skip':
            try:
                times = json.loads(text)
                if isinstance(times, list) and all(isinstance(t, str) for t in times):
                    banner['times'] = times
                else:
                    bot.send_message(chat_id, "فرمت ساعت‌ها نادرست است.")
                    return True
            except:
                bot.send_message(chat_id, "فرمت ساعت‌ها اشتباه است.")
                return True

        # Save changes and finish editing
        banners[index] = banner
        save_banners(banners)
        editing_banners.pop(chat_id)
        bot.send_message(chat_id, "بنر با موفقیت ویرایش شد.")
        return True

    return False
