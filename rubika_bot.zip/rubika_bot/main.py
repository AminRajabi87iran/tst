import asyncio
import threading
from rubpy import Client
from madules.storage import load_banners, save_banners, delete_banner_by_id
from madules.add import handle_add_banner
from madules.edit import handle_edit_banner
from madules.list import handle_list_banners
from madules.scheduler import run_scheduler
from madules.system_status import monitor_system

IMAGES_DIR = 'files/banner_images'


def main() -> None:
    pending_banners = {}
    editing_banners = {}
    chat_ids = set()

    with Client(name='rubpy') as bot:
        print('Bot Started...')

        saved_msg_id = bot.get_me()['user']['user_guid']

        threading.Thread(target=run_scheduler, args=(bot, load_banners, saved_msg_id), daemon=True).start()

        @bot.on_message_updates()
        def handle_message(message) -> None:
            try:
                sender_id = message.is_me
            except:
                sender_id = None

            if not sender_id:
                return

            chat_id = getattr(
                getattr(message, 'chat', None), 'id',
                getattr(getattr(message, 'sender', None), 'id',
                        getattr(message, 'user_guid', None))
            )
            if not chat_id:
                print("Chat Id Not Found , Skipped.")
                return

            chat_id_str: str = str(chat_id)
            chat_ids.add(chat_id_str)

            raw_text = getattr(message, 'text', None)
            text: str = raw_text.strip() if isinstance(raw_text, str) else ''

            banners: list = load_banners()

            if text.lower() == "وضعیت":
                monitor_system(chat_id=chat_id, bot=bot)

            if text.lower() == "لغو":
                if chat_id in editing_banners:
                    editing_banners.pop(chat_id)
                    bot.send_message(chat_id, "عملیات ویرایش لغو شد.")
                    return
                if chat_id in pending_banners:
                    pending_banners.pop(chat_id)
                    bot.send_message(chat_id, "عملیات افزودن لغو شد.")
                    return

            if chat_id in editing_banners:
                if handle_edit_banner(chat_id, text, message, bot, editing_banners, banners, save_banners):
                    return

            if chat_id in pending_banners or text.lower().startswith("افزودن"):
                res = handle_add_banner(chat_id, text, message, bot, pending_banners)
                if res == "save":
                    banners.append(pending_banners.pop(chat_id))
                    save_banners(banners)
                    bot.send_message(chat_id, "بنر با موفقیت ذخیره شد.")
                return

            if text.lower().startswith("ویرایش "):
                banner_id = text[len("ویرایش "):].strip()
                for idx, banner in enumerate(banners):
                    if banner.get("id") == banner_id:
                        editing_banners[chat_id] = {
                            "step": 0,
                            "banner": banner,
                            "index": idx
                        }
                        bot.send_message(chat_id,
                                         f" ویرایش بنر {banner_id} آغاز شد. لطفا متن جدید را وارد کنید یا بنویسید 'skip'.")
                        return
                bot.send_message(chat_id, "بنر مورد نظر پیدا نشد.")
                return

            if text.startswith("حذف "):
                banner_id = text[len("حذف "):].strip()
                if delete_banner_by_id(banner_id, banners, save_banners):
                    bot.send_message(chat_id, f"بنر با شناسه {banner_id} حذف شد.")
                else:
                    bot.send_message(chat_id, "بنری با این شناسه پیدا نشد.")
                return

            if text.lower() == "بنر ها":
                asyncio.run(handle_list_banners(chat_id, bot, banners))
                return

            if text.lower() == "شروع":
                chat_ids.add(chat_id)
                bot.send_message(chat_id, "ارسال خودکار بنرها فعال شد.")
                return

            if text.lower() == "توقف":
                chat_ids.discard(chat_id)
                bot.send_message(chat_id, "ارسال خودکار بنرها غیرفعال شد.")
                return

            if text.lower() == "راهنما":
                help_text = (
                    "راهنما - دستورات ربات:\n\n"
                    "افزودن\n"
                    "ویرایش <id>\n"
                    "حذف <id>\n"
                    "بنر ها\n"
                    "شروع\n"
                    "توقف\n"
                    "لغو\n"
                    "وضعیت\n"
                    "راهنما"
                )
                bot.send_message(chat_id, help_text)
                return

        bot.run()


if __name__ == "__main__":
    main()
